# Job Scraper Context

This project is a Job Scraper Agent built in Python. It aggregates job listings based on a given job title from Naukri, RemoteOK, and Wellfound.

## Architecture
- `models.py`: Defines the `Job` dataclass.
- `csv_writer.py`: Handles exporting `Job` objects to CSV.
- `scrapers/`: Contains the scraping logic for each platform, all inheriting from `BaseScraper`.
