# Job Scraper Agent

A Python-based agent to scrape job listings from various platforms (RemoteOK, Naukri, Wellfound).

## Installation

Ensure you have Python installed, then run:
```bash
pip install -r requirements.txt
```

## Usage

```bash
python -m src.main "Software Engineer"
```

The resulting CSV will be saved in the `output/` directory.
