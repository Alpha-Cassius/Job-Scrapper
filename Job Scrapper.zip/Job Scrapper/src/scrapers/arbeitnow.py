import requests
from typing import List
from src.scrapers.base import BaseScraper
from src.models import Job

class ArbeitnowScraper(BaseScraper):
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        loc_display = location if location else "Global/Remote"
        print(f"[Arbeitnow] Searching for: {job_title} in {loc_display}")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }
        
        result = []
        search_terms = [job_title.lower()]
        if "software engineer" in job_title.lower():
            search_terms.extend(["developer", "software", "engineer", "backend", "frontend", "fullstack", "programmer"])
        
        try:
            # Fetch up to 30 pages (3000 jobs) to find matches
            for page in range(1, 31):
                url = f"https://www.arbeitnow.com/api/job-board-api?page={page}"
                response = requests.get(url, headers=headers, timeout=15)
                
                if response.status_code != 200:
                    break
                    
                data = response.json()
                jobs_data = data.get('data', [])
                
                if not jobs_data:
                    break
                    
                for job in jobs_data:
                    title = job.get('title', '')
                    tags = " ".join(job.get('tags', [])).lower()
                    if any(term in title.lower() or term in tags for term in search_terms):
                        job_loc = job.get('location', 'Not Specified')
                        
                        if location and location.lower() not in job_loc.lower() and not job.get('remote'):
                            continue
                            
                        if job.get('remote'):
                            job_loc = f"{job_loc} (Remote)"
                            
                        result.append(Job(
                            platform='Arbeitnow',
                            title=title,
                            company=job.get('company_name', 'Unknown'),
                            location=job_loc,
                            experience_salary='Not Specified', # Arbeitnow rarely provides salary in API
                            url=job.get('url', '')
                        ))
                        
            print(f"[Arbeitnow] Found {len(result)} matching jobs.")
            return result

        except Exception as e:
            print(f"[Arbeitnow] Error fetching jobs: {e}")
            return result
