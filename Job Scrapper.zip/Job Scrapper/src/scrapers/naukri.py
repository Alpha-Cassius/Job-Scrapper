import requests
from bs4 import BeautifulSoup
from firecrawl import FirecrawlApp
from typing import List
from src.scrapers.base import BaseScraper
from src.models import Job

class NaukriScraper(BaseScraper):
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        import urllib.parse
        
        loc = location.lower() if location else "india"
        print(f"[Naukri] Searching for: {job_title} in {loc}")
        formatted_title_dash = job_title.replace(" ", "-").lower()
        formatted_title_query = urllib.parse.quote(job_title.lower())
        formatted_loc = urllib.parse.quote(loc)
        formatted_loc_dash = loc.replace(" ", "-")
        url = f"https://www.naukri.com/{formatted_title_dash}-jobs-in-{formatted_loc_dash}?k={formatted_title_query}&l={formatted_loc}&experience=1"
        
        api_key = "fc-003b37bb39ca4a8e878203bbf070a115"
        
        try:
            app = FirecrawlApp(api_key=api_key)
            
            print(f"[Naukri] Initiating Firecrawl scrape for {url}...")
            scrape_result = app.scrape(url, formats=['html'])
            
            if not scrape_result or not scrape_result.html:
                print("[Naukri] Failed to retrieve HTML from Firecrawl.")
                return []
                
            soup = BeautifulSoup(scrape_result.html, 'html.parser')
            
            job_cards = soup.find_all('div', class_=lambda c: c and 'jobTuple' in c)
            if not job_cards:
                 job_cards = soup.find_all('div', class_=lambda c: c and 'srp-jobtuple-wrapper' in c)
                 
            if not job_cards:
                print("[Naukri] No job cards found. The page structure might have changed or Naukri blocked the request.")
                return []

            print(f"[Naukri] Found {len(job_cards)} job cards in HTML.")
            
            result = []
            for card in job_cards:
                title_elem = card.find('a', class_='title')
                company_elem = card.find('a', class_='comp-name')
                loc_elem = card.find('span', class_='locWdth')
                exp_elem = card.find('span', class_='expwdth')
                
                title = title_elem.text.strip() if title_elem else 'Unknown'
                company = company_elem.text.strip() if company_elem else 'Unknown'
                location = loc_elem.text.strip() if loc_elem else 'Not Specified'
                experience = exp_elem.text.strip() if exp_elem else 'Not Specified'
                job_url = title_elem['href'] if title_elem and title_elem.has_attr('href') else ''
                
                result.append(Job(
                    platform='Naukri',
                    title=title,
                    company=company,
                    location=location,
                    experience_salary=experience,
                    url=job_url
                ))
                
            return result

        except Exception as e:
            print(f"[Naukri] Error fetching jobs: {e}")
            return []
