import requests
from typing import List
from src.scrapers.base import BaseScraper
from src.models import Job

class JobicyScraper(BaseScraper):
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        loc_display = location if location else "Global/Remote"
        print(f"[Jobicy] Searching for: {job_title} in {loc_display}")
        url = "https://jobicy.com/api/v2/remote-jobs"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }
        
        result = []
        search_terms = [job_title.lower()]
        if "software engineer" in job_title.lower():
            search_terms.extend(["developer", "software", "engineer", "backend", "frontend", "fullstack", "programmer"])
        
        try:
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            data = response.json()
            jobs_data = data.get('jobs', [])
            
            for job in jobs_data:
                title = job.get('jobTitle', '')
                industry = job.get('jobIndustry', [])
                industry_str = " ".join(industry).lower() if isinstance(industry, list) else str(industry).lower()
                if any(term in title.lower() or term in industry_str for term in search_terms):
                    job_loc = job.get('jobGeo', 'Remote')
                    if location and location.lower() not in job_loc.lower() and job_loc.lower() not in ['worldwide', 'remote', 'anywhere']:
                        continue
                        
                    result.append(Job(
                        platform='Jobicy',
                        title=title,
                        company=job.get('companyName', 'Unknown'),
                        location=job_loc,
                        experience_salary=job.get('annualSalaryMax') and f"${job.get('annualSalaryMin')} - ${job.get('annualSalaryMax')}" or 'Not Specified',
                        url=job.get('url', '')
                    ))
                    
            print(f"[Jobicy] Found {len(result)} matching jobs.")
            return result

        except Exception as e:
            print(f"[Jobicy] Error fetching jobs: {e}")
            return result
