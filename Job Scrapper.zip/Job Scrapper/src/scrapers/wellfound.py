import os
from bs4 import BeautifulSoup
from firecrawl import FirecrawlApp
from typing import List
from src.scrapers.base import BaseScraper
from src.models import Job

class WellfoundScraper(BaseScraper):
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        loc_display = location if location else "Global/Remote"
        print(f"[Wellfound] Searching for: {job_title} in {loc_display}")
        
        api_key = "fc-003b37bb39ca4a8e878203bbf070a115"

        formatted_title = job_title.replace(" ", "-").lower()
        url = f"https://wellfound.com/role/l/{formatted_title}"
        
        try:
            app = FirecrawlApp(api_key=api_key)
            
            print(f"[Wellfound] Initiating Firecrawl scrape for {url}...")
            scrape_result = app.scrape(url, formats=['html'])
            
            if not scrape_result or not scrape_result.html:
                print("[Wellfound] Failed to retrieve HTML from Firecrawl.")
                return []

            html_content = scrape_result.html
            soup = BeautifulSoup(html_content, 'html.parser')
            
            job_cards = soup.find_all('div', class_=lambda c: c and 'styles_result__cua10' in c)
            
            if not job_cards:
                 job_cards = soup.find_all('div', {'data-test': 'JobCard'})
                 
            if not job_cards:
                print("[Wellfound] No job cards found in the extracted HTML. Wellfound might have changed their UI.")
                return []

            print(f"[Wellfound] Found {len(job_cards)} job cards.")
            
            result = []
            for card in job_cards:
                title_elem = card.find('a', {'data-test': 'job-title'}) or card.find('a', class_=lambda c: c and 'title' in c.lower())
                company_elem = card.find('a', {'data-test': 'startup-name'}) or card.find('h2')
                loc_elem = card.find('span', {'data-test': 'location'}) or card.find('span', class_=lambda c: c and 'location' in c.lower())
                
                tags = card.find_all('span', class_=lambda c: c and 'tag' in c.lower())
                salary = "Not Specified"
                for tag in tags:
                    if '$' in tag.text or '₹' in tag.text:
                        salary = tag.text.strip()
                        break
                
                title = title_elem.text.strip() if title_elem else 'Unknown'
                company = company_elem.text.strip() if company_elem else 'Unknown'
                loc_text = loc_elem.text.strip() if loc_elem else 'Not Specified'
                job_url = title_elem['href'] if title_elem and title_elem.has_attr('href') else ''
                
                if location and location.lower() not in loc_text.lower() and loc_text.lower() not in ['remote', 'worldwide']:
                    continue
                
                if job_url.startswith('/'):
                    job_url = "https://wellfound.com" + job_url

                result.append(Job(
                    platform='Wellfound',
                    title=title,
                    company=company,
                    location=loc_text,
                    experience_salary=salary,
                    url=job_url
                ))
                
            return result

        except Exception as e:
            print(f"[Wellfound] Error fetching jobs: {e}")
            return []
