import requests
from typing import List
from src.scrapers.base import BaseScraper
from src.models import Job

class RemotiveScraper(BaseScraper):
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        loc_display = location if location else "Global/Remote"
        print(f"[Remotive] Searching for: {job_title} in {loc_display}")
        url = "https://remotive.com/api/remote-jobs"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }
        
        result = []
        search_terms = [job_title.lower()]
        if "software engineer" in job_title.lower():
            search_terms.extend(["developer", "software", "engineer", "backend", "frontend", "fullstack", "programmer"])
        
        try:
            # Fetch without search param to get all jobs, then filter locally
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            data = response.json()
            jobs_data = data.get('jobs', [])
            
            for job in jobs_data:
                title = job.get('title', '')
                if any(term in title.lower() or term in job.get('category', '').lower() for term in search_terms):
                    job_loc = job.get('candidate_required_location', 'Remote')
                    if location and location.lower() not in job_loc.lower() and job_loc.lower() not in ['worldwide', 'remote', 'anywhere', 'global']:
                        continue
                        
                    result.append(Job(
                        platform='Remotive',
                        title=title,
                        company=job.get('company_name', 'Unknown'),
                        location=job_loc,
                        experience_salary=job.get('salary', 'Not Specified'),
                        url=job.get('url', '')
                    ))
                    
            print(f"[Remotive] Found {len(result)} matching jobs.")
            return result

        except Exception as e:
            print(f"[Remotive] Error fetching jobs: {e}")
            return result
