import requests
from typing import List
from src.scrapers.base import BaseScraper
from src.models import Job

class RemoteOKScraper(BaseScraper):
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        loc_display = location if location else "Global/Remote"
        print(f"[RemoteOK] Searching for: {job_title} in {loc_display}")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        try:
            url = "https://remoteok.com/api"
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            jobs_data = response.json()
            
            search_term = job_title.lower()
            loc_term = location.lower() if location else None
            
            filtered_jobs = []
            for job in jobs_data:
                if 'company' in job and 'position' in job:
                    if search_term in job['position'].lower() or search_term in job.get('tags', []):
                        if loc_term:
                            job_loc = job.get('location', '').lower()
                            if loc_term not in job_loc and job_loc not in ['worldwide', 'remote']:
                                continue
                        filtered_jobs.append(job)
            
            print(f"[RemoteOK] Found {len(filtered_jobs)} jobs.")
            
            result = []
            for job in filtered_jobs:
                salary_min = job.get('salary_min')
                salary_max = job.get('salary_max')
                if salary_min and salary_max:
                    exp_salary = f"${salary_min} - ${salary_max}"
                else:
                    exp_salary = "Not Specified"

                result.append(Job(
                    platform='RemoteOK',
                    title=job.get('position', 'Unknown'),
                    company=job.get('company', 'Unknown'),
                    location=job.get('location') or 'Remote',
                    experience_salary=exp_salary,
                    url=job.get('url', '')
                ))
                
            return result

        except Exception as e:
            print(f"[RemoteOK] Error fetching jobs: {e}")
            return []
