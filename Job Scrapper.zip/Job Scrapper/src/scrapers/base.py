from abc import ABC, abstractmethod
from typing import List
from src.models import Job

class BaseScraper(ABC):
    @abstractmethod
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        """
        Scrape jobs from the platform based on the given job title and optional location.
        Returns a list of Job objects.
        """
        pass
