import requests
from bs4 import BeautifulSoup
from typing import List
from src.scrapers.base import BaseScraper
from src.models import Job

class WeWorkRemotelyScraper(BaseScraper):
    def scrape(self, job_title: str, location: str = None) -> List[Job]:
        loc_display = location if location else "Global/Remote"
        print(f"[WeWorkRemotely] Searching for: {job_title} in {loc_display}")
        url = "https://weworkremotely.com/remote-jobs.rss"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }
        
        result = []
        search_terms = [job_title.lower()]
        if "software engineer" in job_title.lower():
            search_terms.extend(["developer", "software", "engineer", "backend", "frontend", "fullstack", "programmer"])
        
        try:
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'xml')
            items = soup.find_all('item')
            
            for item in items:
                title_elem = item.find('title')
                if not title_elem:
                    continue
                    
                title_text = title_elem.text
                if any(term in title_text.lower() for term in search_terms):
                    # WeWorkRemotely titles are usually formatted as "Company Name: Job Title"
                    company = "Unknown"
                    title = title_text
                    if ":" in title_text:
                        parts = title_text.split(":", 1)
                        company = parts[0].strip()
                        title = parts[1].strip()
                        
                    link_elem = item.find('link')
                    url = link_elem.text if link_elem else ""
                    
                    result.append(Job(
                        platform='WeWorkRemotely',
                        title=title,
                        company=company,
                        location="Remote",
                        experience_salary="Not Specified",
                        url=url
                    ))
                    
            print(f"[WeWorkRemotely] Found {len(result)} matching jobs.")
            return result

        except Exception as e:
            print(f"[WeWorkRemotely] Error fetching jobs: {e}")
            return result
