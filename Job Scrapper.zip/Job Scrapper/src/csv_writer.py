import csv
import os
from typing import List
from src.models import Job

def write_jobs_to_csv(jobs: List[Job], filename: str = "output/jobs.csv", append: bool = False):
    if not jobs:
        print("[CSV Writer] No jobs to write to CSV.")
        return

    directory = os.path.dirname(filename)
    if directory:
        os.makedirs(directory, exist_ok=True)

    headers = ['Platform', 'Title', 'Company', 'Location', 'Experience/Salary', 'URL']
    
    file_exists = os.path.isfile(filename)
    mode = 'a' if append else 'w'
    
    try:
        with open(filename, mode=mode, newline='', encoding='utf-8') as file:
            writer = csv.DictWriter(file, fieldnames=headers)
            
            if not append or not file_exists or os.path.getsize(filename) == 0:
                writer.writeheader()
            
            for job in jobs:
                writer.writerow({
                    'Platform': job.platform,
                    'Title': job.title,
                    'Company': job.company,
                    'Location': job.location,
                    'Experience/Salary': job.experience_salary,
                    'URL': job.url
                })
                
        print(f"[CSV Writer] Successfully wrote {len(jobs)} jobs to {filename}")
        
    except Exception as e:
        print(f"[CSV Writer] Error writing to CSV: {e}")
