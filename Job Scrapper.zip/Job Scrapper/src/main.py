import os
import sys
# Add parent directory to path so it can be run directly
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import argparse
import concurrent.futures

from src.scrapers.remoteok import RemoteOKScraper
from src.scrapers.naukri import NaukriScraper
from src.scrapers.wellfound import WellfoundScraper
from src.scrapers.arbeitnow import ArbeitnowScraper
from src.scrapers.jobicy import JobicyScraper
from src.scrapers.remotive import RemotiveScraper
from src.scrapers.weworkremotely import WeWorkRemotelyScraper
from src.csv_writer import write_jobs_to_csv

def main():
    parser = argparse.ArgumentParser(description="Job Scraper Agent")
    parser.add_argument("--job_title", type=str, help="The job title to search for (e.g., 'Software Engineer')")
    parser.add_argument("--location", type=str, default=None, help="The location to search in (e.g., 'India', 'Remote')")
    parser.add_argument("--output", type=str, default="output/jobs.csv", help="Output CSV filename")
    parser.add_argument("--limit", type=int, default=200, help="Number of jobs to save")
    parser.add_argument("--append", action="store_true", help="Append to the output CSV instead of overwriting")
    
    args = parser.parse_args()
    
    # Ask for user input if not provided via CLI args
    job_title = args.job_title
    if not job_title:
        print("=== Job Scraper Agent ===")
        job_title = input("Enter the job title you want to search for: ").strip()
        
    if not job_title:
        print("Job title cannot be empty. Exiting.")
        return
        
    limit = args.limit
    location = args.location
    location_display = location if location else "Global/Remote"
    
    print(f"\nStarting Job Scraper Agent for: '{job_title}' in '{location_display}'\n")
    
    all_jobs = []
    scrapers = [
        RemoteOKScraper(),
        NaukriScraper(),
        WellfoundScraper(),
        ArbeitnowScraper(),
        JobicyScraper(),
        RemotiveScraper(),
        WeWorkRemotelyScraper()
    ]
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(scrapers)) as executor:
        future_to_scraper = {executor.submit(scraper.scrape, job_title, location): scraper for scraper in scrapers}
        
        for future in concurrent.futures.as_completed(future_to_scraper):
            try:
                jobs = future.result()
                all_jobs.extend(jobs)
            except Exception as exc:
                print(f"A scraper generated an exception: {exc}")

    print(f"\nScraping complete. Total jobs found across all platforms: {len(all_jobs)}")
    
    # Enforce limit
    if len(all_jobs) > limit:
        all_jobs = all_jobs[:limit]
        print(f"Limiting output to {limit} jobs as requested.")
        
    if all_jobs:
        write_jobs_to_csv(all_jobs, args.output, append=args.append)
        
        # Show output to the user
        print(f"\n{'='*80}")
        print(f"{'TOP JOBS PREVIEW':^80}")
        print(f"{'='*80}")
        
        # Display up to 15 jobs in the terminal as preview
        preview_limit = min(15, len(all_jobs))
        for i, job in enumerate(all_jobs[:preview_limit], 1):
            title = (job.title[:35] + '..') if len(job.title) > 37 else job.title
            company = (job.company[:20] + '..') if len(job.company) > 22 else job.company
            print(f"{i:02d}. {title:<40} | {company:<25} | [{job.platform}]")
            
        if len(all_jobs) > preview_limit:
            print(f"... and {len(all_jobs) - preview_limit} more jobs.")
            
        print(f"{'='*80}")
        print(f"All {len(all_jobs)} jobs have been saved to '{args.output}'!")
    else:
        print("No jobs found across all platforms.")

if __name__ == "__main__":
    main()
