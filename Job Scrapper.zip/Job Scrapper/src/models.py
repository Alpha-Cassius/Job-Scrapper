from dataclasses import dataclass

@dataclass
class Job:
    platform: str
    title: str
    company: str
    location: str
    experience_salary: str
    url: str
